package com.group158.UrbanAdventure;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrbanAdventureApplication {

	public static void main(String[] args) {
		SpringApplication.run(UrbanAdventureApplication.class, args);
	}

}
